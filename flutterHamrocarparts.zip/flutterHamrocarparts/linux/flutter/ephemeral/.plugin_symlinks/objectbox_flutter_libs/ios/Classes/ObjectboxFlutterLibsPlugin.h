#import <Flutter/Flutter.h>

@interface ObjectboxFlutterLibsPlugin : NSObject<FlutterPlugin>
@end
