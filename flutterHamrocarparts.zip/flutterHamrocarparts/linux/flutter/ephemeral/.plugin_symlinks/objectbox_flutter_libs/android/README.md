Contents of this folder is based on `flutter create --template=plugin`.
It was reduced to the minimum that works for library inclusion by client apps.

Notably, the package depends on `io.objectbox:objectbox-android`, a native ObjectBox library distribution. 