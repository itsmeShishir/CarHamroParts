const baseUrl = "http://192.168.1.8:4000/api/v2/";
// const baseUrl = "http://192.168.254.4:4000/api/v2/";

const loginUrl = "login";
const registerUrl = "register";
const getProductsUrl = "products";
const getProfileUrl = "userdetails";
const getOrderHistoryUrl = "orders/myyy";
const changePasswordUrl = "me/updates";
const getReviewUrl = "product/review";
const potReviewUrl = "/create/product/review";
const updateProfileUrl = "me/update/profiles";
const createOrder = "order/flutter/create";

String? token;
String? email;

// const baseUrl = "http://localhost:4000/api/v2/";
const Token =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYzZmY1YTk0MDFiOTYxN2VhN2U3OTA1YyIsImlhdCI6MTY3NzY3OTI3OCwiZXhwIjoxNjc4MTk3Njc4fQ.MMY-xb8Mn4cFsUz7TpLeXpFcvns1TEYXodpgBrHuVHc";
