import 'package:flutter/cupertino.dart';

class Constants {
  static const PRIMARY_COLOR = Color.fromARGB(255, 0, 183, 97);
}